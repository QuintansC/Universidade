values = [
  int(input("Primeiro valor: ")),
  int(input("Segundo Valor: ")),
  int(input("Terceiro Valor: "))
]
values.sort()
print(values)